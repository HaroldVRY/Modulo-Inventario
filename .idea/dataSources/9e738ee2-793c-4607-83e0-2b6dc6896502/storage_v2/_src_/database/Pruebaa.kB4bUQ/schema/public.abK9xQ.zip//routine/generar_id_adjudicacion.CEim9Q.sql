create function generar_id_adjudicacion() returns trigger
    language plpgsql
as
$$
DECLARE
nuevo_id CHAR(6);
BEGIN
nuevo_id := 'AD' || LPAD(nextval('seq_adjudicacion')::TEXT, 4, '0');
NEW.ID_adjudicacion := nuevo_id;
RETURN NEW;
END;
$$;

alter function generar_id_adjudicacion() owner to postgres;

