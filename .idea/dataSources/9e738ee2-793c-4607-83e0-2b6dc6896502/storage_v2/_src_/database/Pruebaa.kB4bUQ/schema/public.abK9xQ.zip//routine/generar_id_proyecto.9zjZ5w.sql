create function generar_id_proyecto() returns trigger
    language plpgsql
as
$$
DECLARE
  nuevo_id CHAR(6);
BEGIN
  nuevo_id := 'PR' || LPAD(nextval('seq_proyecto')::TEXT, 4, '0');
  NEW.ID_proyecto := nuevo_id;
  RETURN NEW;
END;
$$;

alter function generar_id_proyecto() owner to postgres;

