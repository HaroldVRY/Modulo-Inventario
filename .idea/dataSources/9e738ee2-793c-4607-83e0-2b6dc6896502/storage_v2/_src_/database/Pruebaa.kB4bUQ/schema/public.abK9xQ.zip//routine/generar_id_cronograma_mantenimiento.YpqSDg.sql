create function generar_id_cronograma_mantenimiento() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_cronograma := 'CR' || LPAD(nextval('seq_cronograma_mantenimiento')::TEXT, 4, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_cronograma_mantenimiento() owner to postgres;

