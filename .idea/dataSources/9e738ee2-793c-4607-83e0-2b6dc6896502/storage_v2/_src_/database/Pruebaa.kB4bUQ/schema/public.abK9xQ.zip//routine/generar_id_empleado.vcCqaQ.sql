create function generar_id_empleado() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_empleado := 'E' || LPAD(nextval('seq_empleado')::TEXT, 5, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_empleado() owner to postgres;

