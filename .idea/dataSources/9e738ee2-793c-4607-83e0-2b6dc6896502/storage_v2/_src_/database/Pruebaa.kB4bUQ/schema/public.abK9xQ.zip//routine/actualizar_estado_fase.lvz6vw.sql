create function actualizar_estado_fase() returns trigger
    language plpgsql
as
$$
DECLARE
	total_tareas INT;
	tareas_completadas INT;
BEGIN
	SELECT COUNT(*) INTO total_tareas
	FROM Tarea
	WHERE ID_fase = NEW.ID_fase;
	SELECT COUNT(*) INTO tareas_completadas
	FROM Tarea
	WHERE ID_fase = NEW.ID_fase AND Estado_tarea = 'Completada';
 
	IF tareas_completadas = total_tareas THEN
    	UPDATE Fase SET Estado_Fase = 'Finalizada' WHERE ID_fase = NEW.ID_fase;
	ELSE
    	UPDATE Fase SET Estado_Fase = 'En progreso' WHERE ID_fase = NEW.ID_fase;
	END IF;
 
	RETURN NEW;
END;
$$;

alter function actualizar_estado_fase() owner to postgres;

