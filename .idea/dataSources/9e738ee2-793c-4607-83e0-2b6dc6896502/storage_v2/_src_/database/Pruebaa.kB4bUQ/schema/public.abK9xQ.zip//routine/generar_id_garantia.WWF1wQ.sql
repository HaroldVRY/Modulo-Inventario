create function generar_id_garantia() returns trigger
    language plpgsql
as
$$
DECLARE
nuevo_id CHAR(6);
BEGIN
nuevo_id := 'GA' || LPAD(nextval('seq_garantia')::TEXT, 4, '0');
NEW.ID_garantia := nuevo_id;
RETURN NEW;
END;
$$;

alter function generar_id_garantia() owner to postgres;

