create function insertar_cronograma_infraestructura() returns trigger
    language plpgsql
as
$$
DECLARE
    fecha_inicio DATE;
BEGIN
    -- Calcular la fecha de inicio sumando la frecuencia de mantenimiento a la fecha actual
    fecha_inicio := NEW.fecha_adquisicion + NEW.frecuencia_mantenimiento;

    -- Insertar el cronograma de mantenimiento
    INSERT INTO Cronograma__de_mantenimiento (
        estado,
        fecha_inicio,
        fecha_fin,
        descripcion,
        id_equipo,
        id_infraestructura,
        id_solicitud_mantenimiento
    ) VALUES (
        'P', -- Estado pendiente
        fecha_inicio,
        NULL, -- Fecha fin nula
        'Mantenimiento programado automáticamente', -- Descripción
        NULL, -- Sin equipo
        NEW.ID_infraestructura, -- ID de la infraestructura recién insertada
        NULL  -- Sin solicitud de mantenimiento
    );

    RETURN NEW;
END;
$$;

alter function insertar_cronograma_infraestructura() owner to postgres;

