create function generar_id_requerimiento() returns trigger
    language plpgsql
as
$$
DECLARE
nuevo_id CHAR(6);
BEGIN
nuevo_id := 'RE' || LPAD(nextval('seq_requerimiento')::TEXT, 4, '0');
NEW.ID_requerimiento := nuevo_id;
RETURN NEW;
END;
$$;

alter function generar_id_requerimiento() owner to postgres;

