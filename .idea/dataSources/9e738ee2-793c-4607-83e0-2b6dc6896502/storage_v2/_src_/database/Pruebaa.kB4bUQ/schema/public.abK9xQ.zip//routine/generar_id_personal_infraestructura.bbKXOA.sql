create function generar_id_personal_infraestructura() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_personal_infraestructura := 'EI' || LPAD(nextval('seq_personal_infraestructura')::TEXT, 4, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_personal_infraestructura() owner to postgres;

