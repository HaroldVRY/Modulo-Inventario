create function generar_id_candidato() returns trigger
    language plpgsql
as
$$
DECLARE
    nuevo_id CHAR(6);
BEGIN
    nuevo_id := 'C' || LPAD(nextval('seq_candidato')::TEXT, 5, '0');
    NEW.ID_candidato := nuevo_id;
    RETURN NEW;
END;
$$;

alter function generar_id_candidato() owner to postgres;

