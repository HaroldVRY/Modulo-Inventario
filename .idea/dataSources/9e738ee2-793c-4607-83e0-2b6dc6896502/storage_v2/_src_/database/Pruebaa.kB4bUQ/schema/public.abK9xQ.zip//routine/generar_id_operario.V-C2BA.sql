create function generar_id_operario() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_operario := 'O' || LPAD(nextval('seq_operario')::TEXT, 5, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_operario() owner to postgres;

