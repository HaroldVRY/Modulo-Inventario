create function generar_id_postulacion() returns trigger
    language plpgsql
as
$$
DECLARE
    nuevo_id CHAR(6);
BEGIN
    nuevo_id := 'PS' || LPAD(nextval('seq_postulacion')::TEXT, 4, '0');
    NEW.ID_postulacion := nuevo_id;
    RETURN NEW;
END;
$$;

alter function generar_id_postulacion() owner to postgres;

