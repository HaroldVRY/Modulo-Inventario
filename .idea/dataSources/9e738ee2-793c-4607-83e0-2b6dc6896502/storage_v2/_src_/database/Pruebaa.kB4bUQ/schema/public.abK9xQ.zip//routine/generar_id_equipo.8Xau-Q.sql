create function generar_id_equipo() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_equipo := 'EQ' || LPAD(nextval('seq_equipo')::TEXT, 4, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_equipo() owner to postgres;

