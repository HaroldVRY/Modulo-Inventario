create function generar_id_beneficio() returns trigger
    language plpgsql
as
$$
DECLARE
nuevo_id CHAR(6);
BEGIN
nuevo_id := 'BE' || LPAD(nextval('seq_beneficio')::TEXT, 4, '0');
NEW.ID_beneficio := nuevo_id;
RETURN NEW;
END;
$$;

alter function generar_id_beneficio() owner to postgres;

