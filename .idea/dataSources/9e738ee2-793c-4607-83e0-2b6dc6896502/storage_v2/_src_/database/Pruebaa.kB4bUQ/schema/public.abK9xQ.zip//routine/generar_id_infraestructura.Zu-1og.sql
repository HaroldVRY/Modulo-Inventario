create function generar_id_infraestructura() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_infraestructura := 'INF' || LPAD(nextval('seq_infraestructura')::TEXT, 3, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_infraestructura() owner to postgres;

