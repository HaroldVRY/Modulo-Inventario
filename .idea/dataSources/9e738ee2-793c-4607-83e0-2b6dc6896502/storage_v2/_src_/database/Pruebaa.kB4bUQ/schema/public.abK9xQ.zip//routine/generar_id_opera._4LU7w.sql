create function generar_id_opera() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_historial := 'OP' || LPAD(nextval('seq_opera')::TEXT, 4, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_opera() owner to postgres;

