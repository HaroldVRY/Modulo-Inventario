create function generar_id_vacante() returns trigger
    language plpgsql
as
$$
DECLARE
    nuevo_id CHAR(6);
BEGIN
    nuevo_id := 'V' || LPAD(nextval('seq_vacante')::TEXT, 5, '0');
    NEW.ID_vacante := nuevo_id;
    RETURN NEW;
END;
$$;

alter function generar_id_vacante() owner to postgres;

