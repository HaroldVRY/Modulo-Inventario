create function generar_id_solicitud_mantenimiento() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_solicitud_mantenimiento := 'SM' || LPAD(nextval('seq_solicitud_mantenimiento')::TEXT, 4, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_solicitud_mantenimiento() owner to postgres;

