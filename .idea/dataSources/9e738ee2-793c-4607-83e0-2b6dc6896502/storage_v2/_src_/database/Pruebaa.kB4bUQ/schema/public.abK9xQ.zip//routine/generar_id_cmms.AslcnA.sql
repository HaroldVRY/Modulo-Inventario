create function generar_id_cmms() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ID_cmms := 'CMM' || LPAD(nextval('seq_cmms')::TEXT, 3, '0');
    RETURN NEW;
END;
$$;

alter function generar_id_cmms() owner to postgres;

