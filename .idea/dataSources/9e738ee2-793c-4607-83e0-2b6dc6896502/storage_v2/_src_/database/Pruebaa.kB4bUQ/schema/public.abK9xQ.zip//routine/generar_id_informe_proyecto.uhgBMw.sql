create function generar_id_informe_proyecto() returns trigger
    language plpgsql
as
$$
DECLARE
  nuevo_id CHAR(6);
BEGIN
  nuevo_id := 'INF' || LPAD(nextval('seq_informe_proyecto')::TEXT, 3, '0');
  NEW.ID_informe := nuevo_id;
  RETURN NEW;
END;
$$;

alter function generar_id_informe_proyecto() owner to postgres;

