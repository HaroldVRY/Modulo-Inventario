create function generar_id_fase() returns trigger
    language plpgsql
as
$$
DECLARE
  nuevo_id CHAR(6);
BEGIN
  nuevo_id := 'F' || LPAD(nextval('seq_fase')::TEXT, 5, '0');
  NEW.ID_fase := nuevo_id;
  RETURN NEW;
END;
$$;

alter function generar_id_fase() owner to postgres;

